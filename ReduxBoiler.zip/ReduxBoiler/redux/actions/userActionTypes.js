export const USER_LOADING = "USER_LOADING";
export const USER_RETURN_MSG = "USER_RETURN_MSG";
export const USER_CHANGE_VALUE = "USER_CHANGE_VALUE";

export const LOGIN = "LOGIN";
export const SOCIAL_FB_LOGIN = "SOCIAL_FB_LOGIN";
export const LOGOUT = "LOGOUT";
export const SIGNUP = "SIGNUP";
